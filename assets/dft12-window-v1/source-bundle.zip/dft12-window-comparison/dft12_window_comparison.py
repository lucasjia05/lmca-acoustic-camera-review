"""Site-format maps for 30/N256/K12/24-bit and 30/N512/K12/24-bit."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import copy,json,csv,hashlib,html,shutil
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .area_candidates import config_for,SCENES
from .config import load_config
from .compact_pcm import CompactPCM
from .evaluate_suite import score_map
from .fft_review import render_map_grid
from .area_estimator import Configuration,estimate

ROOT=Path(__file__).resolve().parents[1]
INPUT=ROOT/'results/hardware_cost/fft_comparison'
OUT=ROOT/'results/hardware_cost/dft12_window_comparison'
BUNDLE=ROOT/'docs/review/dft12-window-comparison'
SPECS={'previous26':(512,10,26),'chosen24':(512,10,24),'n256_k12':(256,12,24),'n512_k12':(512,12,24)}

def main():
    OUT.mkdir(parents=True,exist_ok=True);BUNDLE.mkdir(parents=True,exist_ok=True)
    base=load_config(ROOT/'config/exploration.toml');cfgs={};models={};costs={}
    measured=json.loads((ROOT/'results/hardware_cost/dft24_gate_check/decision.json').read_text())['measurements']
    for name,(n,k,w) in SPECS.items():
        frac=w-(n-1).bit_length()-1
        cfgs[name]=config_for(base,(30,k,n,frac,3.,1,n));models[name]=CompactPCM(cfgs[name],frac)
        assert models[name].width==w
        e=estimate(Configuration(microphones=30,window_samples=n,hop_samples=n,selected_bins=k,accumulator_fraction=frac))
        actual=next((x['gate_equivalents'] for x in measured if x['window_samples']==n and x['bins']==k and x['accumulator_width']==w),e['measured_ge'])
        costs[name]=dict(gates=actual if actual is not None else e['estimated_ge'],measured=actual is not None,
                        accumulator_width=w,accumulator_fraction=frac,window_samples=n,bins=k,observation_ms=1000*n/192000,
                        flags=[] if actual is not None else e['flags'])
    # Connect the two N512/24-bit models to the just-verified RTL fixtures.
    anchor_count=0
    for name in ['chosen24','n512_k12']:
        k=SPECS[name][1];folder=ROOT/f'results/hardware_cost/dft24_gate_check/m30_n512_k{k}_acc24'
        for scene in ['baseline','random']:
            f=folder/scene
            pcm=np.array([int(x,16) for x in (f/'pcm_expected.mem').read_text().split()],dtype=np.int64)
            pcm=np.where(pcm>=32768,pcm-65536,pcm).reshape(2,512,30)
            expected=np.array([int(x,16) for x in (f/'map_expected.mem').read_text().split()],dtype=np.int64).reshape(2,441)
            for i in range(2):
                actual,clips=models[name].frame(pcm[i]);assert clips==0 and np.array_equal(actual,expected[i]),(name,scene,i)
                anchor_count+=1
    meta=json.loads((INPUT/'scene_metadata.json').read_text(encoding='utf-8'))
    prior=json.loads((INPUT/'measurements.json').read_text())
    lookup={(r['scene'],r['seed'],r['variant']):r for r in prior}
    with np.load(INPUT/'maps.npz') as old:
        data={key:old[key] for key in old.files if key.endswith('__reference_long') or key=='directions__reference_long'}
        old26={s:old[s+'__dft30_10'] for s in SCENES}
    rows=[];hashes={}
    for scene in SCENES:
        for seed in [7,23,91]:
            path=INPUT/f'recording_{scene}_{seed}.npz';hashes[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
            with np.load(path) as recording:
                assert np.allclose(recording['microphones'][60:90],models['previous26'].mics)
                pcm=recording['pcm'][60:90]
            refpeak=lookup[scene,seed,'reference_long']['score']['peak_power_pcm_squared']
            for name,model in models.items():
                power,clips=model.run(pcm);assert clips==0,(scene,seed,name)
                if seed==7:
                    data[scene+'__'+name]=power
                    if name=='previous26':assert np.array_equal(power,old26[scene])
                rows.append(dict(scene=scene,seed=seed,variant=name,zero_output=bool(power.max()==0),clipped_values=clips,
                    peak_ratio_db=float(10*np.log10(power.max()/refpeak)) if power.max()>0 and refpeak>0 else None,
                    score=score_map(power,model.directions,meta[scene]['truth'],tolerance_deg=2.2)))
        print(scene,'complete',flush=True)
    for name,model in models.items():data['directions__'+name]=model.directions
    np.savez_compressed(OUT/'maps.npz',**data)
    summaries=[]
    for name in SPECS:
        for scene in SCENES:
            rs=[r for r in rows if r['variant']==name and r['scene']==scene]
            ratios=[r['peak_ratio_db'] if r['peak_ratio_db'] is not None else -np.inf for r in rs]
            median=float(np.median(ratios))
            summaries.append(dict(variant=name,scene=scene,matched=sum(r['score']['matched_sources'] for r in rs),
                targets=sum(r['score']['source_count'] for r in rs),zero_maps=sum(r['zero_output'] for r in rs),
                median_peak_ratio_db=median if np.isfinite(median) else None,
                median_extra_peaks=float(np.median([r['score']['off_target_candidate_count'] for r in rs]))))
    for filename,obj in [('measurements.json',rows),('summary.json',summaries),('configurations.json',cfgs),('costs.json',costs),('scene_metadata.json',meta)]:
        (OUT/filename).write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')
    # Easy-to-integrate seed7 grids for the site; full numerical results remain above.
    (OUT/'display-maps.json').write_text(json.dumps({k:v.tolist() for k,v in data.items()},separators=(',',':'))+'\n',encoding='utf-8')
    validation=dict(new_maps=len(rows),scenes=len(SCENES),seeds=[7,23,91],displayed_seed=7,rtl_anchor_maps=anchor_count,
        exact_previous26_seed7_map_matches=len(SCENES),recording_sha256=hashes,
        notes=['Same recordings/reference/normalization as gate-count-study figures19-22.',
               'Width24 is total accumulator width: Q15 at N256, Q14 at N512; other stage formats held fixed.',
               'Candidates process one window starting at the same sample. Shorter N observes less time.',
               'N256/K12 gate count is estimated; N512/K12 and N512/K10 are measured. No new synthesis here.',
               'Synthetic PCM scene comparisons, no real-drone, calibrated SPL, PDM filter or continuous capture claim.'])
    (OUT/'validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none','text.color':'#172033'})
    def label(name):
        if name=='reference_long':return 'Software reference\n30 mics / N512 / all 53 bins\n8 windows / 21.33 ms\nNot a near-budget candidate'
        p=costs[name];heading={'previous26':'Earlier favorite','chosen24':'Chosen 10-bin baseline','n256_k12':'Requested: shorter window','n512_k12':'Requested: 12 bins'}[name]
        return f"{heading}\n30 mics / N{p['window_samples']} / {p['bins']} bins\n{p['accumulator_width']} bits / Q{p['accumulator_fraction']} / {p['observation_ms']:.2f} ms\n{p['gates']/1000:.1f}k GE {'measured' if p['measured'] else 'ESTIMATED'}"
    def footer(fig,_):
        fig.text(.035,.025,'Cyan rings: true sources. White +: brightest pixel, not a detection. Every panel is normalized independently to -12...0 dB.\nReference observes 21.33 ms; candidates observe 1.33 or 2.67 ms. Read the peak-power labels as well as the colors.\nSame recordings as the FFT/DFT comparison gallery. Synthetic PCM only. N256 area is estimated; no claim that it meets the 295k cutoff.',fontsize=9,color='#475569')
    groups=[('01-signals',['unequal6','three','tone30000','pulses'],'30-mic DFT: sources, tones and bursts'),
        ('02-stress',['independent10','mismatch_small','noise_only','outside'],'30-mic DFT: interference and controls'),
        ('03-spatial',['single','edge','equal','close3','unequal12'],'30-mic DFT: location and source separation'),
        ('04-interference',['tone','independent0','near_noise','tone_interference'],'30-mic DFT: tones and stronger noise')]
    cards=[]
    for stem,scenes,title in groups:
        fig=render_map_grid(stem,list(SPECS),scenes,title,'reference_long',data,meta,label,footer)
        # Allow the four-line labels to sit clear of the heading and first row.
        fig.subplots_adjust(top=.77)
        for ext in ['png','svg']:fig.savefig(BUNDLE/f'{stem}.{ext}',dpi=160,facecolor='white')
        plt.close(fig)
        cards.append(dict(stem=stem,title=title,caption='Both requested 24-bit candidates beside the earlier 26-bit favorite and chosen 24-bit/10-bin baseline. Same recordings, reference and display settings as the existing gallery.',alt=title))
    (BUNDLE/'charts.json').write_text(json.dumps(cards,indent=2)+'\n',encoding='utf-8')
    readme=['# 30-microphone, 12-bin, 24-bit candidate plots','',
        'Generated for site handoff; no website publishing or production-default changes. Four galleries cover all17 existing scenes, with seed7 displayed and three seeds scored (204 new maps).','',
        'Columns: existing long software reference; earlier30/N512/10/26; chosen30/N512/10/24; requested30/N256/12/24; requested30/N512/12/24.','',
        '| Candidate | Accumulator | Observation | Gate count |','|---|---|---:|---|']
    for name,p in costs.items():readme.append(f"| 30 / {p['window_samples']} / {p['bins']} / {p['accumulator_width']} | {p['accumulator_width']} total, {p['accumulator_fraction']} fractional bits | {p['observation_ms']:.3f} ms | {p['gates']:,.2f} {'measured' if p['measured'] else 'estimated, not synthesized'} |")
    readme+=['','All use192 ksample/s, 20-40 kHz, 20 cm spiral, 60-degree FOV per axis and3-degree scan grid. Selected bin indices and frequencies are in configurations.json. N256 retains12 of27 in-band centers; N512 retains12 of53. Neither is full-bin coverage.','',
        'Panels use inferno, -12 to0 dB relative to their own peaks, cyan true-source rings and a white brightest-pixel marker. Zero output has no fabricated peak. Peak labels compare with the same N512/53-bin/eight-window software reference as the prior matched FFT/DFT gallery.','',
        'The N256 candidate uses Q15 and N512 uses Q14 to keep both total accumulators at24 bits. This compares the requested fixed-width designs, rather than isolating window length with exactly equal fractional precision. Shorter windows also see less of the same recording; pulse timing can materially change their map.','',
        'Both N512/24-bit PCM models exactly matched all8 map fixtures from the recent RTL verification. The earlier26-bit baseline exactly reproduced all17 previously saved seed7 maps. N256 is a PCM-model exploration, not a newly verified/synthesized RTL result.','',
        'Results are synthetic map diagnostics, not calibrated PD detection probabilities, noise rejection or field sensitivity. No new frequency sweep, motion test or live-video test is implied. Gate evidence and the295k choice remain unchanged.','',
        'For integration: charts.json, PNG/SVG figures, display-maps.json (all seed7 intensity vectors and direction coordinates), configurations.json, scene_metadata.json, measurements.json, summary.json and validation.json. Reproduce with python -m exploration.dft12_window_comparison.']
    (BUNDLE/'README.md').write_text('\n'.join(readme)+'\n',encoding='utf-8')
    for p in OUT.iterdir():
        if p.suffix in ['.json','.npz']:shutil.copy2(p,BUNDLE/p.name)
    shutil.copy2(__file__,BUNDLE/'dft12_window_comparison.py')
    (BUNDLE/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>30-mic 12-bin comparisons</title><style>body{font:16px/1.5 system-ui;max-width:1400px;margin:40px auto;padding:0 20px}img{width:100%;height:auto}</style><h1>30-mic DFT: 12-bin candidates</h1><a href="README.md">Methods and captions</a>'+''.join(f'<section><h2>{html.escape(c["title"])}</h2><a href="{c["stem"]}.png"><img src="{c["stem"]}.png" alt="{html.escape(c["alt"])}"></a></section>' for c in cards),encoding='utf-8')
    manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in BUNDLE.iterdir() if p.is_file() and p.name!='manifest.json'}
    (BUNDLE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    shutil.make_archive(str(BUNDLE),'zip',root_dir=BUNDLE.parent,base_dir=BUNDLE.name)
    print('Complete:',len(rows),'maps;',anchor_count,'RTL anchors;',BUNDLE,flush=True)

if __name__=='__main__':main()
