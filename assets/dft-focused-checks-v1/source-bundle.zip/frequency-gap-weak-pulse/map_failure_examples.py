"""Controlled visual diagnostics for the 30-mic / 10-bin / 26-bit DFT candidate."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import copy, json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .fft_comparison import configs
from .compact_pcm import CompactPCM
from .evaluate_suite import unit_vectors

OUT=Path(__file__).resolve().parents[1]/'results/hardware_cost/map_failure_examples'

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    cfg=configs()['dft30_10']; full=copy.deepcopy(cfg)
    full['processing']['bin_indices']=list(range(54,107))
    models={'candidate':CompactPCM(cfg,16),'all_bins':CompactPCM(full,16),'higher_precision':CompactPCM(cfg,24)}
    m=models['candidate']; truth=np.array([-12.,6.]); u=unit_vectors([truth])[0]
    delay=m.mics@u/343.; t=np.arange(512)/192000
    shifted=t[None,:]+delay[:,None]; target=int(np.argmin(np.sum((m.directions-truth)**2,axis=1)))
    records=[]; saved={'directions':m.directions,'truth':truth}; groups={}
    # A retained center and the midpoint of the neighboring 28.875/31.125 kHz centers.
    conditions=[('Selected frequency, quiet',28875.,None),('Between selected frequencies, quiet',30000.,None),
                ('Selected frequency + noise',28875.,-26.),('Between selected frequencies + noise',30000.,-26.)]
    for row,(label,hz,noise) in enumerate(conditions):
        for seed in (7,23,91):
            rng=np.random.default_rng(seed);phase=rng.uniform(0,2*np.pi)
            pcm=np.sqrt(2)*10**(-26/20)*np.sin(2*np.pi*hz*shifted+phase)
            if noise is not None:pcm+=rng.normal(0,10**(noise/20),pcm.shape)
            for key in ('candidate','all_bins'):
                power,clips=models[key].run(pcm); idx=int(np.argmax(power))
                err=float(np.degrees(np.arccos(np.clip(unit_vectors([m.directions[idx]])[0]@u,-1,1)))) if power.max()>0 else None
                records.append(dict(group='frequency',row=row,seed=seed,model=key,hz=hz,noise_dbfs=noise,peak_error_deg=err,
                                    target_power=float(power[target]),peak_power=float(power.max()),clipped_values=clips))
                if seed==7:saved[f'frequency_{row}_{key}']=power
    groups['frequency']=conditions
    # Identical broadband 20.25--39.75 kHz bursts, centered in the window.
    levels=(-30.,-50.,-65.,-80.)
    for row,level in enumerate(levels):
        for seed in (7,23,91):
            rng=np.random.default_rng(seed);freqs=np.arange(54,107)*375.
            phases=rng.uniform(0,2*np.pi,len(freqs))
            wave=np.sin(2*np.pi*shifted[:,:,None]*freqs+phases).sum(axis=2)
            wave*=np.exp(-.5*((shifted-256/192000)/.00008)**2)
            pcm=wave/np.max(abs(wave))*10**(level/20)
            for key in ('candidate','higher_precision'):
                power,clips=models[key].run(pcm);idx=int(np.argmax(power))
                err=float(np.degrees(np.arccos(np.clip(unit_vectors([m.directions[idx]])[0]@u,-1,1)))) if power.max()>0 else None
                records.append(dict(group='weak',row=row,seed=seed,model=key,pulse_peak_dbfs=level,peak_error_deg=err,
                                    target_power=float(power[target]),peak_power=float(power.max()),clipped_values=clips))
                if seed==7:saved[f'weak_{row}_{key}']=power
    assert all(r['clipped_values']==0 for r in records)
    np.savez_compressed(OUT/'maps.npz',**saved)
    (OUT/'measurements.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
    (OUT/'configuration.json').write_text(json.dumps(dict(candidate=cfg,seeds=[7,23,91],displayed_seed=7,
        source_direction=truth.tolist(),notes=['Synthetic PCM-stage tests; no measured discharge, PDM, MEMS or flight noise.',
        'Full-bin and higher-precision controls are software controls, not asserted to fit 300k.',
        'All maps independently normalized; strongest point and target/peak contrast shown.',
        'Pulse levels are maximum input sample amplitude across the array, not SPL or RMS.',
        'Zero-output maps have no estimated peak. Shared PCM/output quantization remains in both precision variants.']),indent=2)+'\n',encoding='utf-8')
    for group,keys,titles in [('frequency',('candidate','all_bins'),('30 mics / 10 bins / 26-bit','Same array / all 53 bins / 26-bit')),
                              ('weak',('candidate','higher_precision'),('30 mics / 10 bins / 26-bit','Same array / same bins / 34-bit'))]:
        fig,axes=plt.subplots(4,2,figsize=(11,13.2));fig.subplots_adjust(left=.10,right=.88,top=.90,bottom=.11,hspace=.65,wspace=.24)
        fig.suptitle('Frequency gaps: does the hotspot still point correctly?' if group=='frequency' else 'Weak pulses: what survives the fixed-point pipeline?',fontsize=16,y=.995)
        fig.text(.5,.955,'Cyan ring = real source     white + = brightest map pixel\nEach panel uses its own peak, displayed from -12 to 0 dB. Same first seed throughout.',ha='center',fontsize=10)
        for row in range(4):
            for col,key in enumerate(keys):
                ax=axes[row,col];p=saved[f'{group}_{row}_{key}'];nonzero=p.max()>0
                db=10*np.log10(np.maximum(p/max(float(p.max()),1e-300),1e-12))
                z=db.reshape(21,21).T
                im=ax.imshow(z,origin='lower',extent=[-31.5,31.5,-31.5,31.5],vmin=-12,vmax=0,cmap='inferno',aspect='equal')
                ax.scatter(*truth,facecolors='none',edgecolors='cyan',s=115,linewidths=1.8)
                if nonzero:ax.scatter(*m.directions[int(np.argmax(p))],marker='+',color='white',s=120,linewidths=1.8)
                else:ax.text(0,0,'NO NONZERO OUTPUT',ha='center',color='white',fontsize=10)
                rec=next(r for r in records if r['group']==group and r['row']==row and r['seed']==7 and r['model']==key)
                err='no peak' if rec['peak_error_deg'] is None else f"peak error {rec['peak_error_deg']:.1f} deg"
                contrast=10*np.log10(max(float(p[target]),1e-300)/max(float(p.max()),1e-300)) if nonzero else None
                detail=f'target/peak {contrast:.1f} dB' if contrast is not None else 'output rounded to zero'
                label=f"{conditions[row][1]/1000:g} kHz | {'quiet' if conditions[row][2] is None else '0 dB input SNR'}" if group=='frequency' else f'Pulse peak {levels[row]:g} dBFS | quiet'
                ax.set_title((titles[col]+'\n' if row==0 else '')+label,fontsize=10)
                ax.set_xlabel(err+' | '+detail,fontsize=8);ax.set_ylabel('Elevation (deg)',fontsize=8)
                ax.set_xticks([-30,0,30]);ax.set_yticks([-30,0,30]);ax.tick_params(labelsize=8)
        fig.colorbar(im,cax=fig.add_axes([.91,.25,.017,.47]),label='dB relative to each map peak')
        foot='Frequency changes only; same source level, position, array and noise realization.\nAll-bin control isolates missing frequencies; it is not a 300k-gate candidate.' if group=='frequency' else 'Precision changes only; both models retain the same 16-bit PCM input and 48-bit map output.\nA failure shared by both is not evidence against the 26-bit accumulator specifically.'
        fig.text(.10,.035,foot+'\nSynthetic diagnostic maps, not calibrated sound levels or field detection rates.',fontsize=10)
        fig.savefig(OUT/f'{group}-maps.png',dpi=160);plt.close(fig)
    for group in ('frequency','weak'):
        for row in range(4):
            rr=[r for r in records if r['group']==group and r['row']==row]
            print(group,row,[(r['model'],r['seed'],r['peak_error_deg'],r['peak_power']) for r in rr],flush=True)

if __name__=='__main__':main()
